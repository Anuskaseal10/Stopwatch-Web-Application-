var timer;
var minutes = 0;
var seconds = 0;
var milliseconds = 0;

function displayTime() {
    var minuteString = minutes < 10 ? "0" + minutes : minutes;
    var secondString = seconds < 10 ? "0" + seconds : seconds;
    var millisecondString = milliseconds < 10 ? "0" + milliseconds : milliseconds;
    document.querySelector(".minute").innerText = minuteString + " :";
    document.querySelector(".sec").innerText = secondString + " :";
    document.querySelector(".msec").innerText = millisecondString;
}

function start() {
    timer = setInterval(function() {
        milliseconds++;
        if (milliseconds === 100) {
            milliseconds = 0;
            seconds++;
            if (seconds === 60) {
                seconds = 0;
                minutes++;
            }
        }
        displayTime();
    }, 10);
}

function reset() {
    clearInterval(timer);
    minutes = 0;
    seconds = 0;
    milliseconds = 0;
    displayTime();
    document.getElementById("lapList").innerHTML = "";
}

function recordLap() {
    if (timer) { // Only record laps if the timer is running
        var lapTime = document.querySelector(".minute").innerText.trim() + " " +
                      document.querySelector(".sec").innerText.trim() + " " +
                      document.querySelector(".msec").innerText.trim();

        var lapItem = document.createElement("li"); // Corrected variable name
        lapItem.textContent = lapTime;
        document.getElementById("lapList").appendChild(lapItem);
    }
}